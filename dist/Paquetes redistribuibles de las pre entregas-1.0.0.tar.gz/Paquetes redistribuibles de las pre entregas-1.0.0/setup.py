from setuptools import setup

setup(
    name = "Paquetes redistribuibles de las pre entregas",
    version = "1.0.0",
    description = "Paquetes redistribuibles de las pre entregas del curso de Python",
    author = "Rosas Sandillú, Julián",
    packages = ["Segunda-pre-entrega-Rosas Sandillu"]
)
